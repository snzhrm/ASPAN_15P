from app import create_app, db
from app.models import User, Restaurant, MenuItem, CartItem, Order, OrderItem, Product
from werkzeug.security import generate_password_hash

def init_data():
    app = create_app()
    with app.app_context():
        # Создаем рестораны
        restaurants = [
            {
                'name': 'KFC',
                'description': 'Kentucky Fried Chicken - всемирно известная сеть ресторанов быстрого питания',
                'menu_items': [
                    {'name': 'Боксмастер', 'description': 'Куриное филе, салат, помидор, соус', 'price': 1990},
                    {'name': 'Твистер', 'description': 'Куриное филе, салат, помидор, соус', 'price': 1290},
                    {'name': 'Картофель фри', 'description': 'Хрустящий картофель фри', 'price': 390},
                    {'name': 'Кола', 'description': 'Газированный напиток', 'price': 290}
                ]
            },
            {
                'name': 'Salam Bro',
                'description': 'Ресторан восточной кухни',
                'menu_items': [
                    {'name': 'Шаурма', 'description': 'Лаваш, курица, овощи, соус', 'price': 1490},
                    {'name': 'Фалафель', 'description': 'Вегетарианские шарики из нута', 'price': 990},
                    {'name': 'Микс гриль', 'description': 'Ассорти из мяса на гриле', 'price': 2490},
                    {'name': 'Айран', 'description': 'Традиционный кисломолочный напиток', 'price': 290}
                ]
            },
            {
                'name': 'YOLO',
                'description': 'Ресторан современной кухни',
                'menu_items': [
                    {'name': 'Бургер', 'description': 'Котлета, сыр, салат, соус', 'price': 1790},
                    {'name': 'Пицца', 'description': 'Тонкое тесто, сыр, томатный соус', 'price': 1990},
                    {'name': 'Салат Цезарь', 'description': 'Курица, салат, сухарики, соус', 'price': 1290},
                    {'name': 'Мохито', 'description': 'Освежающий коктейль', 'price': 890}
                ]
            }
        ]

        # Добавляем рестораны и их меню
        for restaurant_data in restaurants:
            restaurant = Restaurant(
                name=restaurant_data['name'],
                description=restaurant_data['description']
            )
            db.session.add(restaurant)
            db.session.commit()

            for item_data in restaurant_data['menu_items']:
                menu_item = MenuItem(
                    name=item_data['name'],
                    description=item_data['description'],
                    price=item_data['price'],
                    restaurant_id=restaurant.id
                )
                db.session.add(menu_item)
            db.session.commit()

        # Создаем администратора, если его нет
        admin = User.query.filter_by(email='admin@example.com').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@example.com',
                password_hash=generate_password_hash('admin'),
                is_admin=True
            )
            db.session.add(admin)
            db.session.commit()

        print("Данные успешно инициализированы!")

if __name__ == '__main__':
    init_data() 